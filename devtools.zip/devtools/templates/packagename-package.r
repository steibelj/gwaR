#' {{{ name }}}.
#'
#' @name {{{ name }}}
#' @docType package
NULL
